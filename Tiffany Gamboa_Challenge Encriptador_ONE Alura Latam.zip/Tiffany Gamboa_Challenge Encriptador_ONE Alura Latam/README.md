# Challenge Encriptador de texto con JavaScript
Encriptador de texto desarrollado en HTML, CSS y JavaScript
Primer Challenge de ONE-Oracle Next Education | Alura Latam.


Las "Claves" de encriptación utilizadas son las siguientes:

`La letra "e" es convertida para "ext"`
`La letra "i" es convertida para "imk"`
`La letra "a" es convertida para "alm"`
`La letra "o" es convertida para "ors"`
`La letra "u" es convertida para "udp"`

**Requisitos:**
- Uso solamente de letras minúsculas
- No deben utilizarse letras con acentos ni caracteres especiales
- Debe encriptada una palabbra y también devolver una palabra encriptada para su versión original. 

Por ejemplo:
`"hola" => "horslalm"`
`horslalm" => "hola"`

- La página debe tener espacios para: 
1-Colocar el texto que será encriptado o desencriptado
2-Opciones de encriptado y desencriptado que el usuario pueda seleccionar
3-El resultado debe apareer en pantalla.

**Extras:**
- Un botón que copie el texto encriptado/desencriptado para la sección de transferencia, o sea que tenga la misma funcionalidad del `ctrl+C` o de la opción "copiar" del menú de las aplicaciones.

Este proyecto fue realizado por Tiffany Gamboa.
Como el primer Challenge de ONE-Oracle Next Education | Alura Latam.
Grupo G6 - 2024.