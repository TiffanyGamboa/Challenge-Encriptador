
//Mostrar resultado//
function resultado(){
    var inputText = document.querySelector("#input-texto").value;  
    if (inputText=== ""){
        document.getElementById("botonCopiar").style.display = "none";
        document.getElementById("divImagen").style.display ="block";
    } else{
        document.getElementById("botonCopiar").style.display = "block";
        document.getElementById("divImagen").style.display = "none";
    }
}


//Quitar la imagen//
function quitarImagen() {
    document.getElementById("divImagen").style.display = "none";
}


//Encriptador//
function encriptar (){
    const caracteres = /[A-Z0-9~!@#$%&*()_+|{}[\]\\\/?><^:"`;.,áéíóúàèìòù']/g;
    var texto = document.querySelector("#input-texto").value;
    if (texto == ""){
        alert("Lo siento, el espacio no debe estar vacío.");
    } else if (texto.match(caracteres) != texto.match(caracteres)){
        alert("El texto no puede contener Mayusculas, acentos, ni caracteres especiales. Por favor, intenta de nuevo.");
    } else{
        var textoCifrado = texto.replace(/e/gi, "ext").replace(/i/gi, "imk").replace(/a/gi, "alm").replace(/o/gi, "ors").replace(/u/gi, "udp");        document.querySelector(".text-input-salida").value = textoCifrado;
        document.querySelector("#input-texto").value;         
        document.getElementById("msg").style.visibility = "visible";
        document.getElementById("btn-copy").style.visibility = "visible";
        quitarImagen();
    } 
}
//Boton encriptar//
var boton1 = document.querySelector("#btn-encriptar"); boton1.onclick = encriptar;


//Desencriptador//
function desencriptar (){
     var texto = document.querySelector("#input-texto").value; 
     var textoCifrado = texto.replace(/ext/gi, "e").replace(/imk/gi, "i").replace(/alm/gi, "a").replace(/ors/gi, "o").replace(/udp/gi, "u"); 
     document.querySelector(".text-input-salida").value = textoCifrado; 
     document.querySelector("#input-texto").value;
     document.getElementById("msg").style.visibility = "visible";
     document.getElementById("btn-copy").style.visibility = "visible";
}
//Boton desencriptar//
var boton2 = document.querySelector("#btn-desencriptar"); 
boton2.onclick = desencriptar;


//Copiar texto//
function copiarTexto(){
    //Obtenemos el campo de texto.
    var copiar = document.getElementById("msg");
    //Selecionamos el campo de texto.
    copiar.select();
    copiar.setSelectionRange(0, 99999); //Rango para moviles.
    //Copia aquello que se encuentra dentro del campo de texto.
    navigator.clipboard.writeText(copiar.value);
    //Alerta de validación de la copia del texto.
    alert("Se copio el texto:  " + copiar.value);
    console.log(alert);
}
//boton copiar// 
var botonCopiar = document.querySelector("#btn-copy");
// Acción al dar un clic al boton copiar con la función copiar. 
botonCopiar.onclick = copiarTexto;